import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js";
import { getAuth, GoogleAuthProvider, signInWithPopup, signInAnonymously, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js";
import { getFirestore, collection, addDoc, getDocs, query, orderBy, limit, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyDcIyaxre8rUZGMaBLpDSlZrYegZ33zttk",
  authDomain: "neon-drop-ultra.firebaseapp.com",
  projectId: "neon-drop-ultra",
  storageBucket: "neon-drop-ultra.firebasestorage.app",
  messagingSenderId: "911506561330",
  appId: "1:911506561330:web:663c70ffb7d63833765f2b",
  measurementId: "G-VS14G619SC"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

export function watchAuth(callback) {
  return onAuthStateChanged(auth, callback);
}

export async function googleLogin() {
  const provider = new GoogleAuthProvider();
  return await signInWithPopup(auth, provider);
}

export async function guestLogin() {
  return await signInAnonymously(auth);
}

export async function submitScore(name, score, level) {
  const user = auth.currentUser;
  if (!user) throw new Error("ログインが必要です");
  await addDoc(collection(db, "rankings"), {
    uid: user.uid,
    name,
    score,
    level,
    createdAt: serverTimestamp()
  });
}

export async function getRanking() {
  const q = query(collection(db, "rankings"), orderBy("score", "desc"), limit(20));
  const snap = await getDocs(q);
  return snap.docs.map(doc => doc.data());
}
