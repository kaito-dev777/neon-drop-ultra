import { googleLogin, guestLogin, submitScore, getRanking, watchAuth } from "./firebase.js";

const SIZE = 6;
let COLORS = ["#ff006e","#00f5d4","#fee440","#8338ec","#fb5607"];
let board = [];
let score = 0;
let coins = parseInt(localStorage.getItem("ultra_coins") || "500");
let level = parseInt(localStorage.getItem("ultra_level") || "1");
let playerStats = JSON.parse(localStorage.getItem("ultra_stats") || '{"power":1,"coin":1,"combo":1}');
let currentUserName = localStorage.getItem("ultra_user") || "Guest";

const $ = (id) => document.getElementById(id);

function sound(freq, duration) {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.value = freq;
    osc.type = "sawtooth";
    osc.start();
    gain.gain.exponentialRampToValueAtTime(.0001, ctx.currentTime + duration / 1000);
    osc.stop(ctx.currentTime + duration / 1000);
  } catch(e) {}
}

function showCombo(text) {
  const el = $("combo");
  el.innerText = text;
  el.classList.remove("show");
  void el.offsetWidth;
  el.classList.add("show");
}

function flash() {
  document.body.animate([{filter:"brightness(1)"},{filter:"brightness(1.6)"},{filter:"brightness(1)"}], {duration:180});
}

function randomColor() {
  return COLORS[Math.floor(Math.random() * COLORS.length)];
}

function generate() {
  board = [];
  for (let i = 0; i < SIZE * SIZE; i++) board.push(randomColor());
}

function neighbors(i) {
  const r = Math.floor(i / SIZE);
  const c = i % SIZE;
  const n = [];
  if (r > 0) n.push(i - SIZE);
  if (r < SIZE - 1) n.push(i + SIZE);
  if (c > 0) n.push(i - 1);
  if (c < SIZE - 1) n.push(i + 1);
  return n;
}

function draw() {
  $("grid").innerHTML = "";
  board.forEach((color, i) => {
    const tile = document.createElement("div");
    tile.className = "tile";
    tile.style.background = color;
    tile.onclick = () => tap(i);
    $("grid").appendChild(tile);
  });

  $("score").innerText = score;
  $("coins").innerText = coins;
  $("level").innerText = level;
  $("statsText").innerHTML = `現在：パワー${playerStats.power} / コイン倍率${playerStats.coin} / コンボ倍率${playerStats.combo}`;
}

function tap(start) {
  const color = board[start];
  const stack = [start];
  const visited = new Set();

  while (stack.length) {
    const current = stack.pop();
    if (visited.has(current)) continue;
    visited.add(current);
    neighbors(current).forEach(n => {
      if (board[n] === color && !visited.has(n)) stack.push(n);
    });
  }

  if (visited.size >= 3) {
    let gain = visited.size * 20 * playerStats.power;

    if (visited.size >= 6) {
      gain *= playerStats.combo;
      showCombo("🔥 COMBO");
      sound(500,120);
    } else {
      showCombo("⚡ NICE");
      sound(350,80);
    }

    score += gain;
    coins += Math.floor(gain / 5) * playerStats.coin;

    if (score > level * 1000) {
      level++;
      showCombo("🆙 LEVEL UP");
      sound(900,200);
    }

    visited.forEach(v => board[v] = randomColor());
    saveLocal();
    flash();
  }

  draw();
}

function saveLocal() {
  localStorage.setItem("ultra_coins", coins);
  localStorage.setItem("ultra_level", level);
  localStorage.setItem("ultra_stats", JSON.stringify(playerStats));
}

async function refreshRanking() {
  const el = $("ranking");
  el.innerHTML = "読み込み中...";

  try {
    const ranking = await getRanking();
    el.innerHTML = "";
    if (!ranking.length) {
      el.innerHTML = "<div class='notice'>まだランキングがありません</div>";
      return;
    }
    ranking.forEach((r, i) => {
      const row = document.createElement("div");
      row.className = "rank";
      row.innerHTML = `<span>#${i + 1} ${r.name || "Guest"}</span><span>${r.score || 0}</span>`;
      el.appendChild(row);
    });
  } catch (e) {
    el.innerHTML = `<div class='notice'>ランキング取得エラー: ${e.message}</div>`;
  }
}

async function sendScore() {
  try {
    await submitScore(currentUserName, score, level);
    showCombo("🏆 SENT");
    await refreshRanking();
    alert("Firebaseにスコア送信成功！");
  } catch (e) {
    alert("送信エラー: " + e.message);
  }
}

$("googleLoginBtn").onclick = async () => {
  try {
    const result = await googleLogin();
    currentUserName = result.user.displayName || "Player";
    localStorage.setItem("ultra_user", currentUserName);
    $("username").innerText = currentUserName;
    showCombo("✨ GOOGLE LOGIN");
  } catch (e) {
    alert("Googleログインエラー: " + e.message);
  }
};

$("guestLoginBtn").onclick = async () => {
  try {
    await guestLogin();
    currentUserName = "Guest";
    localStorage.setItem("ultra_user", currentUserName);
    $("username").innerText = currentUserName;
    showCombo("✨ GUEST LOGIN");
  } catch (e) {
    alert("ゲストログインエラー: " + e.message);
  }
};

$("submitScoreBtn").onclick = sendScore;
$("refreshRankingBtn").onclick = refreshRanking;

$("gachaBtn").onclick = () => {
  if (coins < 100) {
    $("gachaResult").innerText = "❌ コイン不足";
    return;
  }

  coins -= 100;
  const items = ["🌈 LEGEND SKIN","💎 1000 COINS","🔥 POWER UP","⚡ ULTRA BONUS","👑 MYTHIC CHARACTER"];
  const item = items[Math.floor(Math.random() * items.length)];
  $("gachaResult").innerText = item;

  if (item === "💎 1000 COINS") coins += 1000;
  if (item === "🔥 POWER UP") playerStats.power++;
  if (item === "⚡ ULTRA BONUS") score += 2000;
  if (item === "👑 MYTHIC CHARACTER") {
    playerStats.power += 2;
    playerStats.combo += 2;
  }

  showCombo("✨ RARE");
  sound(700,180);
  saveLocal();
  draw();
};

$("adBtn").onclick = () => {
  showCombo("📺 AD BONUS");
  sound(450,150);
  setTimeout(() => {
    coins += 300;
    saveLocal();
    draw();
    alert("広告報酬で300コインGET！");
  }, 500);
};

document.querySelectorAll("[data-upgrade]").forEach(btn => {
  btn.onclick = () => {
    const type = btn.dataset.upgrade;
    if (coins < 200) {
      alert("コイン不足！");
      return;
    }
    coins -= 200;
    playerStats[type]++;
    showCombo("⬆️ 強化成功");
    sound(600,150);
    saveLocal();
    draw();
  };
});

watchAuth((user) => {
  if (user) {
    currentUserName = user.displayName || localStorage.getItem("ultra_user") || "Guest";
    $("username").innerText = currentUserName;
    $("loginStatus").innerText = "Firebase接続済み / UID: " + user.uid.slice(0, 8);
  } else {
    $("loginStatus").innerText = "未ログイン";
  }
});

generate();
draw();
refreshRanking();
guestLogin().catch(() => {});
